from setuptools import setup, find_packages

setup(name="Ausweis_webcab_automation", packages=find_packages())