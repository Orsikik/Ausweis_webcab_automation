from .login_page import LoginPage
from pytest import mark

@mark.login
class LoginTests:
    def test_login(self, chrome):
        chrome.get('https://www.google.com')
        assert True

    # login_page = LoginPage(chrome_browser)