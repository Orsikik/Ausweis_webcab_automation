from browser_setting_up import browser
from pytest import mark
from login_page import LoginPage


@mark.login
class LoginTest:
    login_page = LoginPage(browser)

    def test_login_wrong_data(self):
        self.login_page.go()
        assert True


